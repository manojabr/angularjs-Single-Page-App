package com.consolidator.mail;

import java.awt.Desktop;
import java.io.*;
import com.consolidator.mail.app.*;
import com.consolidator.mail.config.*;

public class MailConsolidator {

	public MailConsolidator setUp() throws Exception {
		if (!Setup.getSettingsfile().exists()) {
			Setup.generateSettingsfile();
		}
		if (!Setup.getCacheFile().exists()) {
			Setup.createCacheFile();
		}
		return this;
	}

	public void consolidateToMailfile() throws Exception {

		if (!Setup.getMailDir().exists()) {
			Setup.createDirectory();
		}

		/*
		 * File file = new File(Config.getMailFile()); file.createNewFile();
		 * Config.contentWriter(file, contentMaker.getConsolidatedContent());
		 */
		try (OutputStream out = new FileOutputStream(Setup.getMailFile())) {
			System.out.println("Mail File Created");
			App.GenerateEMLFile().writeTo(out);
			System.out.println("Content has been Updated to the mail");
		}

	}

	public void close() throws Exception {
		System.out.println(
				"Process completed.. Consolidated Mail in " + Setup.getMailFile() + "\nFolder will be opens shortly");
		if (Setup.getCacheFile().exists()) {
			Setup.deleteCacheFile();
		}
		Thread.sleep(400);

		Desktop.getDesktop().open(new File(Setup.getMailDir().getAbsolutePath()));
	}
}
