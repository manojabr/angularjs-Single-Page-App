package com.consolidator.mail.config;

import java.io.*;
import java.nio.file.*;

public class Setup {

	static final String ROOT_DIR = System.getProperty("user.dir");
	static final String SettingsFile = "settings.json";
	static final String Directory_Separator = "//";
	static final String MAIL_FILE = "consolidate.eml";
	static final String MAIL_DIR = "Output";
	private static String tblrange;
	private static String[] startIndex;
	private static String[] endIndex;
	private static String regex = "(?<=\\D)(?=\\d)";
	static String temp = "";
	static String CacheFileName = "cacheFiles.txt";
	static File CacheFile = null;

	public static void setTblRange(String tblnge) {
		tblrange = tblnge;
		temp = tblrange.substring(0, tblrange.indexOf(":"));
		startIndex = temp.split(getRegex());
		temp = tblrange.substring(tblrange.indexOf(":") + 1);
		endIndex = temp.split(getRegex());
	}

	public static String getRegex() {
		return regex;
	}

	public static String getCacheFileName() {
		return getDir() + getDirectorySeparator() + CacheFileName;
	}

	public static File getCacheFile() {
		CacheFile = new File(getCacheFileName());
		return CacheFile;
	}

	public static boolean createCacheFile() throws Exception {
		return CacheFile.createNewFile();
	}

	public static boolean deleteCacheFile() throws Exception {
		return CacheFile.delete();
	}

	public static String readCacheFile() throws Exception {
		return new String(Files.readAllBytes(Paths.get(getCacheFileName())));
	}

	public static void UpdateCacheFile(String Content) throws Exception {
		contentWriter(CacheFile, Content, true);
	}

	public String getTblRange() {
		return tblrange;
	}

	public static String getTblRangeStartNo() {
		return startIndex[1];
	}

	public static String getTblRangeStartLtr() {
		return startIndex[0];
	}

	public static String getTblRangeEndNo() {
		return endIndex[1];
	}

	public static String getTblRangeEndLtr() {
		return endIndex[0];
	}

	public static String getMailFile() {
		return getDir() + getDirectorySeparator() + MAIL_DIR + getDirectorySeparator() + MAIL_FILE;
	}

	public static String getDir() {
		return ROOT_DIR;
	}

	public static String getSettingfileName() {
		return SettingsFile;
	}

	public static String getDirectorySeparator() {
		return Directory_Separator;
	}

	private static File settingsFile = null, dir = null;

	public static String getRootDirectoryPath() {
		return getDir();
	}

	public static File getSettingsfile() {
		settingsFile = new File(getDir() + getDirectorySeparator() + getSettingfileName());
		return settingsFile;
	}

	public static File getMailDir() {
		dir = new File(getDir() + getDirectorySeparator() + MAIL_DIR + getDirectorySeparator());
		return dir;
	}

	public static void createDirectory() {
		dir.mkdirs();
	}

	public static void generateSettingsfile() throws Exception {
		settingsFile.createNewFile();
		contentWriter(settingsFile, getjsonContent(), false);
	}

	public static int getColumnIdx(String column) {
		char[] arr = column.toCharArray();
		char temp = 'A';
		int index = 0;
		for (int i = 0; i < arr.length; i++) {
			temp = arr[i];
			int j = 0;
			for (char a = 'A'; a <= 'Z'; a++) {
				if (temp == a) {
					index += j;
					break;
				}
				j++;
			}
			index = j;
		}
		return index;
	}

	static FileWriter writer;

	public static void contentWriter(File file, String content, Boolean isAppendText) throws Exception {
		if (isAppendText)
			writer = new FileWriter(file, true);
		else
			writer = new FileWriter(file);

		try {
			writer.write(content);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			writer.flush();
			writer.close();
		}
	}

	public static String getjsonContent() {

		return "{\r\n"
				+ "	\"greetingMsg\": \"Please find daily productivity\\r\\n report for K2 streams and the overall summary\",\r\n"
				+ "	\"infoMsg\": \"**Please note: below mentioned productivity data is created by productivity consolidator,\",\r\n"
				+ "	\"RolloutTracker\": [\r\n" + "		{\r\n"
				+ "			\"FileName\": \"Kemper R2 State Rollout Productivity Tracker.xlsm\",\r\n"
				+ "			\"SheetName-0\": \"R2 State Rollout\",\r\n" + "			\"tblind-0\": \"A3:G13\"\r\n"
				+ "		},\r\n" + "		{\r\n" + "			\"SheetName-1\": \"R2-BA\",\r\n"
				+ "			\"tblind-1\": \"A2:G24\"\r\n" + "		},\r\n" + "		{\r\n"
				+ "			\"SheetName-2\": \"R2-Agency Portal\",\r\n" + "			\"tblind-2\": \"A2:G9\"\r\n"
				+ "		},\r\n" + "		{\r\n" + "			\"SheetName-3\": \"R2-Comprater\",\r\n"
				+ "			\"tblind-3\": \"A2:G9\"\r\n" + "		},\r\n" + "		{\r\n"
				+ "			\"SheetName-4\": \"R2-GW Config\",\r\n" + "			\"tblind-4\": \"A2:G10\"\r\n"
				+ "		},\r\n" + "		{\r\n" + "			\"SheetName-5\": \"R2-GW-Integ\",\r\n"
				+ "			\"tblind-5\": \"A2:G9\"\r\n" + "		},\r\n" + "		{\r\n"
				+ "			\"SheetName-6\": \"R2-Forms\",\r\n" + "			\"tblind-6\": \"A2:G11\"\r\n"
				+ "		},\r\n" + "		{\r\n" + "			\"SheetName-7\": \"R2-PERS\",\r\n"
				+ "			\"tblind-7\": \"A2:G13\"\r\n" + "		},\r\n" + "		{\r\n"
				+ "			\"SheetName-8\": \"R2-QA\",\r\n" + "			\"tblind-8\": \"A2:T10\"\r\n"
				+ "		}\r\n" + "	],\r\n" + "	\"individual_tracker\": [\r\n" + "		{\r\n"
				+ "			\"FileName-1\": \"R2 AgencyPortal Productivity Tracker.xlsx\",\r\n"
				+ "			\"tblind-1\": \"A2:G24\",\r\n" + "			\"summaryPgSheetName-1\": \"Summary\"\r\n"
				+ "		},\r\n" + "		{\r\n" + "			\"FileName-2\": \"R2 B A  Productivity tracker.xlsx\",\r\n"
				+ "			\"tblind-2\": \"A2:G24\",\r\n" + "			\"summaryPgSheetName-2\": \"Day Summary\"\r\n"
				+ "		},\r\n" + "		{\r\n"
				+ "			\"FileName-3\": \"R2 Comprater Productivity Tracker.xlsx\",\r\n"
				+ "			\"tblind-3\": \"A2:G24\",\r\n" + "			\"summaryPgSheetName-3\": \"Day Summary\"\r\n"
				+ "		},\r\n" + "		{\r\n" + "			\"FileName-4\": \"R2 GW Productivity Tracker.xlsx\",\r\n"
				+ "			\"tblind-4\": \"A2:G24\",\r\n" + "			\"summaryPgSheetName-4\": \"Summary\"\r\n"
				+ "		},\r\n" + "		{\r\n"
				+ "			\"FileName-5\": \"R2 Integ Dev Productivity Tracker.xlsx\",\r\n"
				+ "			\"tblind-5\": \"A2:G24\",\r\n" + "			\"summaryPgSheetName-5\": \"Summary\"\r\n"
				+ "		},\r\n" + "		{\r\n"
				+ "			\"FileName-6\": \"R2 Forms Dev Productivity Tracker.xlsx\",\r\n"
				+ "			\"tblind-6\": \"A2:G24\",\r\n" + "			\"summaryPgSheetName-6\": \"Summary\"\r\n"
				+ "		},\r\n" + "		{\r\n"
				+ "			\"FileName-7\": \"R2 PERS Dev Productivity Tracker.xlsx\",\r\n"
				+ "			\"tblind-7\": \"A2:G24\",\r\n" + "			\"summaryPgSheetName-7\": \"Summary\"\r\n"
				+ "		},\r\n" + "		{\r\n" + "			\"FileName-8\": \"R2_QA_Productivity Tracker.xlsx\",\r\n"
				+ "			\"tblind-8\": \"A2:G24\",\r\n" + "			\"summaryPgSheetName-8\": \"Summary\"\r\n"
				+ "		}\r\n" + "	],\r\n" + "	\"SheetName-0\": \"R2 State Rollout\",\r\n"
				+ "	\"tblind-0\": \"A3:G13\",\r\n" + "	\"SheetName-1\": \"R2-BA\",\r\n"
				+ "	\"tblind-1\": \"A2:G24\",\r\n" + "	\"SheetName-2\": \"R2-Agency Portal\",\r\n"
				+ "	\"tblind-2\": \"A2:G9\",\r\n" + "	\"SheetName-3\": \"R2-Comprater\",\r\n"
				+ "	\"tblind-3\": \"A2:G9\",\r\n" + "	\"SheetName-4\": \"R2-GW Config\",\r\n"
				+ "	\"tblind-4\": \"A2:G10\",\r\n" + "	\"SheetName-5\": \"R2-GW-Integ\",\r\n"
				+ "	\"tblind-5\": \"A2:G9\",\r\n" + "	\"SheetName-6\": \"R2-Forms\",\r\n"
				+ "	\"tblind-6\": \"A2:G11\",\r\n" + "	\"SheetName-7\": \"R2-PERS\",\r\n"
				+ "	\"tblind-7\": \"A2:G13\",\r\n" + "	\"SheetName-8\": \"R2-QA\",\r\n"
				+ "	\"tblind-8\": \"A2:T10\"\r\n" + "}\r\n" + "";
	}

}
