package com.consolidator.mail;

import java.awt.Desktop;
import java.io.*;
import com.consolidator.mail.app.*;
import com.consolidator.mail.config.*;

public class MailConsolidator {

	public MailConsolidator setUp() throws Exception {
		if (!Config.getSettingsfile().exists()) {
			Config.generateSettingsfile();
			System.out.println(Config.getSettingsfile().getAbsolutePath());
		}

		return this;
	}

	public void consolidateToMailfile() throws Exception {

		if (!Config.getMailDir().exists()) {
			Config.createDirectory();
		}
		/*
		 * File file = new File(Config.getMailFile()); file.createNewFile();
		 * 
		 * Config.contentWriter(file, contentMaker.getConsolidatedContent());
		 */
		try (OutputStream out = new FileOutputStream(Config.getMailFile())) {
			System.out.println("Mail File Created");
			app.GenerateEMLFile().writeTo(out);
			System.out.println("Content has been Updated to the mail");
		}

	}

	public void close() throws Exception {
		System.out.println(
				"Process completed.. Consolidated Mail in " + Config.getMailFile() + "\nFolder will be opens shortly");
		Thread.sleep(1000);
		Desktop.getDesktop().open(new File(Config.getMailDir().getAbsolutePath()));
	}
}
