package com.consolidator.mail;

public class MailConsolidatorApp {

	public static void main(String[] args) throws Exception {
		MailConsolidator consolidate = new MailConsolidator();
		consolidate.setUp().consolidateToMailfile();
		consolidate.close();
	}

}
