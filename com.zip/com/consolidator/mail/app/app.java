package com.consolidator.mail.app;

import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;

public class app {
	private static Address[] fromAddress, toAddress;
	private static Session session;
	static MimeMessage msg;
	static Properties properties;

	public static MimeMessage GenerateEMLFile() throws Exception {

		msg = setup();
		MimeBodyPart textPart = new MimeBodyPart();
		textPart.setText("Body's text (text)", "UTF-8");
		MimeBodyPart htmlPart = new MimeBodyPart();
		htmlPart.setContent(contentMaker.getConsolidatedContent(), "text/html; charset=UTF-8");
		Multipart multiPart = new MimeMultipart("alternative");
		multiPart.addBodyPart(textPart); // first
		multiPart.addBodyPart(htmlPart); // second
		msg.setContent(multiPart);
		msg.addHeader("X-Custom-Header", "CustomValue");
		return msg;

	}

	protected static MimeMessage setup() throws AddressException, MessagingException {
		properties = new Properties();
		properties.put("mail.files.path", "");
		session = Session.getDefaultInstance(properties);
		fromAddress = new Address[] { new InternetAddress("abc@test.com") };
		toAddress = new Address[] { new InternetAddress("zzczxcr@capgemini.com") };
		msg = new MimeMessage(session);
		msg.addFrom(fromAddress);
		msg.setReplyTo(toAddress);
		msg.setSubject("subject");
		return msg;
	}

}
