package com.consolidator.mail.app;

import static j2html.TagCreator.*;
import java.io.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.*;
import org.apache.poi.xssf.usermodel.*;
import org.json.simple.*;
import org.json.simple.parser.*;

import com.consolidator.mail.config.Config;

import j2html.tags.*;

public class contentMaker {
	private static JSONParser parser;
	private static JSONObject jsnObj;
	private static String[][] MergeMap;
	private static XSSFWorkbook wb;
	private static FileInputStream fis;
	private static String regex = "(?<=\\D)(?=\\d)", RolloutTracker = "";
	private static int startRowIdx = 0;
	private static String[] files = null;

	public static String getConsolidatedContent() throws Exception {
		files = getExcelFiles();
		parser = new JSONParser();
		jsnObj = (JSONObject) parser.parse(new FileReader(Config.getSettingsfile().getAbsolutePath()));

		String mainContent = "", content = "";
		content = createLeaveTable();
		RolloutTracker = getTrackerbyName();
		for (int i = 0; i <= 8; i++) {
			content += getContentFromTracker(getJsnObj("tblind-" + i), i);
		}
		mainContent = html(getHeaderTag(), getHTMLBody(content)).render();
		return mainContent;

	}

	private static String[] getExcelFiles() {
		String fold = "C:\\excelFiles\\";
		String[] fil = { fold + "Kemper R2 State Rollout Productivity Tracker.xlsm",
				fold + "R2 AgencyPortal Productivity Tracker.xlsx", fold + "R2 B A  Productivity tracker.xlsx",
				fold + "R2 Comprater Productivity Tracker.xlsx", fold + "R2 Forms Dev Productivity Tracker.xlsx",
				fold + "R2 GW Productivity Tracker.xlsx", fold + "R2 Integ Dev Productivity Tracker.xlsx",
				fold + "R2 PERS Dev Productivity Tracker.xlsx", fold + "R2 State Roll Out Leave Tracker.xlsx",
				fold + "R2_QA_Productivity Tracker.xlsx" };

		return fil;
	}

	private static String getJsnObj(String obj) {
		return jsnObj.get(obj).toString();
	}

	private static String getTrackerbyName() {

		for (String file : files) {
			if (file.contains("Rollout ")) {
				return file;
			}
		}

		return "";
	}

	private static String getContentFromTracker(String tblIdx, int summaryPageIndex) throws Exception {
		fis = new FileInputStream(new File(RolloutTracker));
		wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheet(getJsnObj("Name-" + summaryPageIndex));
		MergeMap = getContentArray(sheet, tblIdx);
		printarray();
		String content = "";

		for (int i = 0; i < MergeMap.length; i++) {
			content += tr(rawHtml(getEachRowContent(sheet, i, startRowIdx)))
					.withStyle("height:" + ((i == 1) ? "24.5pt" : "14.5pt") + ";").render();
		}

		return table(tbody(rawHtml(content))).attr("align", "left").attr("class", "MsoNormalTable")
				.withStyle("width:1056.7pt;border-collapse:collapse;margin:6.75pt;").render()
				+ p().attr("class", "MsoNormal").render() + p().attr("class", "MsoNormal").render();
	}

	private static String getEachRowContent(XSSFSheet xssfSheet, int i, int startRowIndex) {
		String content = "";
		String arrayValue = "";
		for (int j = 0; j < MergeMap[i].length; j++) {
			int startId = 0;
			int endId = 0;
			int diff = 0;
			diff = endId - startId;
			diff = diff + 1;
			arrayValue = MergeMap[i][j];
			if (arrayValue.contains("--")) {
				String[] splitedString = getSplited(arrayValue, "--"); // A2:G29--$BE
				Config.setTblRange(arrayValue.substring(0, arrayValue.indexOf("-")));

				if (Config.getRangeStartLtr().equals(Config.getRangeEndLtr())) {
					diff = Integer.parseInt(Config.getRangeEndNo()) - Integer.parseInt(Config.getRangeStartNo());
					diff = diff + 1;
					if (!splitedString[1].equals("$")) {
						content += printElement(xssfSheet, i, j, "", diff + "", startRowIndex - 1);
					}
				} else if (!Config.getRangeStartLtr().equals(Config.getRangeEndLtr())) {
					diff = Config.getColumnIdx(Config.getRangeEndLtr())
							- Config.getColumnIdx(Config.getRangeStartLtr());
					diff = diff + 1;
					if (!splitedString[1].equals("$")) {
						content += printElement(xssfSheet, i, j, diff + "", "", startRowIndex - 1);
					}
				}
			} else {
				content += printElement(xssfSheet, i, j, "", "", startRowIndex - 1);
			}
		}

		return content;
	}

	private static String printElement(XSSFSheet xssfSheet, int i, int j, String colspan, String rowspan,
			int startRowIdx) {
		String value;
		if (xssfSheet.getRow(i + startRowIdx).getCell(j).getCellType() == CellType.STRING
				|| xssfSheet.getRow(i + startRowIdx).getCell(j).getCellType() == CellType.BLANK) {
			value = xssfSheet.getRow(i + startRowIdx).getCell(j).getStringCellValue();
		} else {
			value = xssfSheet.getRow(i + startRowIdx).getCell(j).getRawValue() + "";
		}
		value = td(p(span(value).withStyle(getTextColor(i, j) + ";font-size:" + ((i == 0) ? "11.pt" : "9.pt;")))
				.attr(".MsoNormal").attr("align", "left"))
						.attr("width", ((j == MergeMap[1].length - 1) ? "135" : "104"))
						.attr("colspan", ((colspan.equals("")) ? "" : colspan))
						.attr("rowspan", ((rowspan.equals("")) ? "" : rowspan)).attr("valign", "center")
						.withStyle("border:solid #A6A6A6 1.0pt;" + getbackgrdColor(i, j)).render();
		value.replaceAll("colspan=\"\"", "");
		value.replaceAll("rowspan=\"\"", "");

		return value;
	}

	private static String getTextColor(int i, int j) {
		String str = "";
		if (i == 0 || i == MergeMap.length - 1) {
			str = "color:#FFFFFF;";
		} else if (j == 0 && (i != 0 && i != MergeMap.length - 1)) {
			str = "color:#000000;font-family:\"Bookman Old Style\",\"serif\";";
		} else {
			str = "color:#000000;";
		}
		return str;
	}

	private static String getbackgrdColor(int i, int j) {
		String str = "";
		if (i == 0 || i == MergeMap.length - 1) {
			str = "background:#1F3864;";
		} else if (i == 1) {
			str = "background:#8EAADB;";
		} else {
			str = "background:#FFFFFF;";
		}
		return str;
	}

	private static void printarray() {
		for (int i = 0; i < MergeMap.length; i++) {
			for (int j = 0; j < MergeMap[i].length; j++) {
				System.out.print(MergeMap[i][j] + " \t");
			}
			System.out.print("\n");
		}
		System.out.println("\n\n\n\n");
	}

	private static String[][] getContentArray(XSSFSheet xssfSheet, String tblIdx) {
		String[] splitedByColon = getSplited(tblIdx, ":"), startRow = getSplited(splitedByColon[0], regex),
				endRow = getSplited(splitedByColon[1], regex);
		String[][] arr = new String[(Integer.parseInt(endRow[1]) - Integer.parseInt(startRow[1]))
				+ 1][Config.getColumnIdx(endRow[0]) - Config.getColumnIdx(startRow[0]) + 1];

		startRowIdx = Integer.parseInt(startRow[1]);
		System.out.println(arr.length + " " + arr[0].length);

		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				String val = "";
				if (getMergedRegionForCell(xssfSheet.getRow(i + (startRowIdx - 1)).getCell(j)) != null) {
					val = "" + getMergedRegionForCell(xssfSheet.getRow(i + (startRowIdx - 1)).getCell(j));
				}
				if (xssfSheet.getRow(i + (startRowIdx - 1)).getCell(j).getCellType() == CellType.STRING
						|| xssfSheet.getRow(i + (startRowIdx - 1)).getCell(j).getCellType() == CellType.BLANK) {
					arr[i][j] = ((val.equals("") || val.equals(null)) ? ""
							: val.substring(val.indexOf("[") + 1, val.indexOf("]")) + "--$")
							+ xssfSheet.getRow(i + (startRowIdx - 1)).getCell(j).getStringCellValue();

				} else {
					arr[i][j] = ((val.equals("") || val.equals(null)) ? ""
							: val.substring(val.indexOf("[") + 1, val.indexOf("]")) + "--$")
							+ xssfSheet.getRow(i + (startRowIdx - 1)).getCell(j).getRawValue() + "";
				}
				val = "";
			}
		}
		return arr;
	}

	public static CellRangeAddress getMergedRegionForCell(Cell c) {
		Sheet s = c.getRow().getSheet();
		for (CellRangeAddress mergedRegion : s.getMergedRegions()) {
			if (mergedRegion.isInRange(c.getRowIndex(), c.getColumnIndex())) {

				return mergedRegion;
			}
		}

		return null;
	}

	private static String[] getSplited(String value, String regex) {
		return value.split(regex);
	}

	private static String createLeaveTable() {
		String padding = "padding:0in 5.4pt 0in 5.4pt;";
		String content = "";
		content += table(
				tr(td(p(b(span(rawHtml("R2 State Rollout Leave Summary for 29<sup>th </sup>October"))
						.withStyle("font-size:10.0pt;color:black;"))).attr("align", "center")
								.withStyle("text-align:center;"))
										.attr("colspan", "4")
										.withStyle("width:764.7pt;border:solid windowtext 1.0pt; background:#FFE699;"
												+ padding + "height:11.5pt")).withStyle("height:11.5pt"),
				tr(td(p(span("Total FTEs").withStyle("font-size:10.0pt;color:black;"))
						.withStyle("text-align:center;font-weight:bold;")).attr("valign", "top")
								.withStyle("border:solid windowtext 1.0pt;background:#BDD7EE;" + padding + ""),
						td(p(span("Planned Leaves").withStyle("font-size:10.0pt;color:black;"))
								.withStyle("text-align:center;font-weight:bold;")).attr("valign", "top")
										.withStyle("border:solid windowtext 1.0pt;background:#BDD7EE;" + padding + ""),
						td(p(span("UnPlanned Leaves").withStyle("font-size:10.0pt;color:black;"))
								.withStyle("text-align:center;font-weight:bold;")).attr("valign", "top")
										.withStyle("border:solid windowtext 1.0pt;background:#BDD7EE;" + padding + ""),
						td(p(span("Work from Home").withStyle("font-size:10.0pt;color:black;"))
								.withStyle("text-align:center;font-weight:bold;")).attr("valign", "top")
										.withStyle("border:solid windowtext 1.0pt;background:#BDD7EE;" + padding + ""))
												.withStyle("height:11.5pt"),
				tr(td(p(span("::84").withStyle("font-size:10.0pt;color:black;"))
						.withStyle("text-align:center;font-weight:bold;")).attr("valign", "top")
								.withStyle("border:solid windowtext 1.0pt;background:#BDD7EE;" + padding + ""),
						td(p(span("::2").withStyle("font-size:10.0pt;color:black;"))
								.withStyle("text-align:center;font-weight:bold;")).attr("valign", "top")
										.withStyle("border:solid windowtext 1.0pt;background:#BDD7EE;" + padding + ""),
						td(p(span("::1").withStyle("font-size:10.0pt;color:black;"))
								.withStyle("text-align:center;font-weight:bold;")).attr("valign", "top")
										.withStyle("border:solid windowtext 1.0pt;background:#BDD7EE;" + padding + ""),
						td(p(span("::1").withStyle("font-size:10.0pt;color:black;"))
								.withStyle("text-align:center;font-weight:bold;")).attr("valign", "top")
										.withStyle("border:solid windowtext 1.0pt;background:#BDD7EE;" + padding + ""))
												.withStyle("height:11.5pt"),
				tr(td(p(span(rawHtml("&nbsp;&nbsp;")).withStyle("font-size:10.0pt;color:black;"))
						.withStyle("text-align:center;")).attr("valign", "top")
								.withStyle("border:solid windowtext 1.0pt;background:white;" + padding + ""),
						td(p(span("1.Suganyha Manoharan").withStyle("font-size:10.0pt;color:black;"))
								.withStyle("text-align:center;")).attr("valign", "top")
										.withStyle("border:solid windowtext 1.0pt;background:white;" + padding + ""),
						td(p(span("1.Prabhu").withStyle("font-size:10.0pt;color:black;"))
								.withStyle("text-align:center;")).attr("valign", "top")
										.withStyle("border:solid windowtext 1.0pt;background:white;" + padding + ""),
						td(p(span("1.Karuna").withStyle("font-size:10.0pt;color:black;"))
								.withStyle("text-align:center;")).attr("valign", "top")
										.withStyle("border:solid windowtext 1.0pt;background:white;" + padding + ""))
												.withStyle("height:11.5pt")).attr("align", "left").withStyle(
														"width:1056.7pt;border-collapse:collapse;margin:6.75pt;")
														.render();
		content += p().render() + p().render() + p().render() + p().render();

		return content;
	}

	private static DomContent getHTMLBody(String string) {

		return body(div(p().attr("class", "MsoNormal"), p().attr("class", "MsoNormal"), p().attr("class", "MsoNormal"),
				p().attr("class", "MsoNormal"),
				p(span("**Please note: below mentioned productivity data is created by productivity consolidator,")
						.withStyle("color:red;")).attr("class", "MsoNormal"),
				p().attr("class", "MsoNormal"),
				p(span("**if you have queries, email us.").withStyle("color:red;")).attr("class", "MsoNormal"),
				p().attr("class", "MsoNormal"), p().attr("class", "MsoNormal"),
				p(span("Hi All,").withStyle("color:#002060;")).attr("class", "MsoNormal"),
				p().attr("class", "MsoNormal"),
				p(span("Please find daily productivity\r\n" + "report for K2 streams and the overall summary")
						.withStyle("color:#002060;")).attr("class", "MsoNormal"),
				p().attr("class", "MsoNormal"), p().attr("class", "MsoNormal"), rawHtml(string)))
						.withStyle("font-family:\"Calibri\",\"sans-serif\";");
	}

	private static DomContent getHeaderTag() {

		return head(style("@font-face\r\n"
				+ "	{font-family:Calibri;} p.MsoNormal, li.MsoNormal, div.MsoNormal,  table.MsoNormalTable\r\n"
				+ "	{margin:0in; margin-bottom:.0001pt;	font-size:11.0pt;font-family:\"Calibri\",\"sans-serif\";}"));
	}

}
