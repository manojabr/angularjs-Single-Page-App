package com.consolidator.mail.app;

import static j2html.TagCreator.*;

import java.io.*;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.*;
import org.apache.poi.xssf.usermodel.*;
import org.json.simple.*;
import org.json.simple.parser.*;

import com.consolidator.mail.config.Config;

import j2html.tags.*;

public class contentMaker {
	private static JSONParser parser;
	private static JSONObject jsnObj;
	private static String[][] MergeMap;
	private static XSSFWorkbook wb;
	private static FileInputStream fis;
	private static final String regex = "(?<=\\D)(?=\\d)";
	private static int startRowIdx = 0;
	private static String[] files = { "Roll out Tracker.xlsx" };

	public static String getConsolidatedContent() throws Exception {
		parser = new JSONParser();
		jsnObj = (JSONObject) parser.parse(new FileReader(Config.getSettingsfile().getAbsolutePath()));

		String mainContent = "", content = "", projectSum = "";

		content = createLeaveTable();
		projectSum = "";

		for (int i = 0; i <= 8; i++) {
			content += getContentFromTracker(getTrackerbyName(i), getJsnObj("tblind-" + i), i);
		}
		mainContent = html(getHeaderTag(), getHTMLBody(projectSum + content)).render();
		return mainContent;

	}

	private static String getJsnObj(String obj) {

		return jsnObj.get(obj).toString();
	}

	private static String getTrackerbyName(int i) {

		for (String file : files) {
			if (file.contains("8888")) {
				return file;
			}
		}

		return "";
	}

	private static String getContentFromTracker(String tracker, String tblIdx, int summaryPageIndex) throws Exception {
		fis = new FileInputStream(new File(tracker));
		wb = new XSSFWorkbook(fis);
		MergeMap = getContentArray(wb.getSheet(getJsnObj("Name-" + summaryPageIndex)), tblIdx);
		printarray();
		String content = "";

		for (int i = 0; i < MergeMap.length; i++) {
			content = tr(rawHtml(getEachRowContent(wb.getSheetAt(summaryPageIndex), i, startRowIdx)))
					.withStyle("height:" + ((i == 1) ? "24.5pt" : "14.5pt") + ";").render();
		}

		return table(tbody(rawHtml(content))).attr("align", "left").attr("class", "MsoNormalTable")
				.withStyle("border-collapse:collapse;margin:6.75pt;").render() + p().attr("class", "MsoNormal").render()
				+ p().attr("class", "MsoNormal").render();

	}

	private static String getEachRowContent(XSSFSheet xssfSheet, int i, int startRowIndex) {
		String content = "";

		String arrayValue = "";
		for (int j = 0; j < MergeMap[i].length; j++) {
			XSSFFont font = xssfSheet.getRow(i + (startRowIndex - 1)).getCell(j).getCellStyle().getFont();
			int startId = 0, endId = 0, diff = 0;
			diff = endId - startId;
			diff = diff + 1;
			arrayValue = MergeMap[i][j];
			if (arrayValue.contains("--")) {
				String[] splitedString = getSplited(arrayValue, "--"), // A2:G29--$BE
						splitUsingColon = getSplited(splitedString[0], ":"), // A2:G29
						stNum_N_Letter = getSplited(splitUsingColon[0], regex), // A2
						endNum_N_Letter = getSplited(splitUsingColon[1], regex);// G9
				if (stNum_N_Letter[0].equals(endNum_N_Letter[0])) {
					diff = Integer.parseInt(endNum_N_Letter[1]) - Integer.parseInt(stNum_N_Letter[1]);
					diff = diff + 1;
					if (!splitedString[1].equals("$")) {
						content += printElement(xssfSheet, i, j, "", diff + "", startRowIndex - 1);
					}
				} else if (!stNum_N_Letter[0].equals(endNum_N_Letter[0])) {

					startId = getColumnIdx(stNum_N_Letter[0]);
					endId = getColumnIdx(endNum_N_Letter[0]);
					diff = endId - startId;
					diff = diff + 1;
					if (!splitedString[1].equals("$")) {
						content += printElement(xssfSheet, i, j, diff + "", "", startRowIndex - 1);

					}
				} else {
					content += printElement(xssfSheet, i, j, "", "", startRowIndex - 1);
				}

			}
		}

		return content;
	}

	private static String printElement(XSSFSheet xssfSheet, int i, int j, String colspan, String rowspan,
			int startRowIdx) {
		XSSFCellStyle cellStyle = xssfSheet.getRow(i + startRowIdx).getCell(j).getCellStyle();
		XSSFColor color = xssfSheet.getRow(i + startRowIdx).getCell(j).getCellStyle().getFillForegroundColorColor();
		String value;
		if (xssfSheet.getRow(i + startRowIdx).getCell(j).getCellType() == CellType.STRING
				|| xssfSheet.getRow(i + startRowIdx).getCell(j).getCellType() == CellType.BLANK) {
			value = xssfSheet.getRow(i + startRowIdx).getCell(j).getStringCellValue();
		} else {
			value = xssfSheet.getRow(i + startRowIdx).getCell(j).getRawValue() + "";
		}
		return td(p(span(value).withStyle("color:#" + cellStyle.getFont().getXSSFColor().getARGBHex().toLowerCase().substring(2)
				+ ";font-size:" + ((i == 0) ? "11.pt" : "9.pt;"))).attr(".MsoNormal").attr("align", "left"))
						.attr("width", ((j == MergeMap[1].length - 1) ? "135" : "104"))
						.attr("colspan", ((colspan.equals("")) ? "0" : colspan))
						.attr("rowspan", ((rowspan.equals("")) ? "0" : rowspan)).attr("valign", "center")
						.withStyle("border:solid #A6A6A6 1.0pt;"
								+ ((color != null) ? "background:#" + color.getARGBHex().toLowerCase().substring(2)
										: "background:#ffffff"))
						.render();
	}

	private static void printarray() {
		for (int i = 0; i < MergeMap.length; i++) {
			for (int j = 0; j < MergeMap[i].length; j++) {
				System.out.print(MergeMap[i][j] + " \t");
			}
			System.out.print("\n");
		}
		System.out.println("\n\n\n\n");
	}

	private static String[][] getContentArray(XSSFSheet xssfSheet, String tblIdx) {
		String[] splitedByColon = getSplited(tblIdx, ":"), startRow = getSplited(splitedByColon[0], regex),
				endRow = getSplited(splitedByColon[1], regex);
		String[][] arr = new String[(Integer.parseInt(endRow[1]) - Integer.parseInt(startRow[1]))
				+ 1][getColumnIdx(endRow[0]) - getColumnIdx(startRow[0]) + 1];
		String val = "";
		startRowIdx = Integer.parseInt(startRow[1]);
		System.out.println(arr.length + " " + arr[0].length);

		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				if (getMergedRegionForCell(xssfSheet.getRow(i + (startRowIdx - 1)).getCell(j)) != null) {
					val = "" + getMergedRegionForCell(xssfSheet.getRow(i + (startRowIdx - 1)).getCell(j));
				}

				if (xssfSheet.getRow(i + (startRowIdx - 1)).getCell(j).getCellType() == CellType.STRING
						|| xssfSheet.getRow(i + (startRowIdx - 1)).getCell(j).getCellType() == CellType.BLANK) {
					arr[i][j] = ((val.equals("") || val.equals(null)) ? ""
							: val.substring(val.indexOf("[") + 1, val.indexOf("]")) + "--$")
							+ xssfSheet.getRow(i + (startRowIdx - 1)).getCell(j).getStringCellValue();

				} else {
					arr[i][j] = ((val.equals("") || val.equals(null)) ? ""
							: val.substring(val.indexOf("[") + 1, val.indexOf("]")) + "--$")
							+ xssfSheet.getRow(i + (startRowIdx - 1)).getCell(j).getRawValue() + "";

				}
			}
		}

		return arr;
	}

	public static CellRangeAddress getMergedRegionForCell(Cell c) {
		Sheet s = c.getRow().getSheet();
		for (CellRangeAddress mergedRegion : s.getMergedRegions()) {
			if (mergedRegion.isInRange(c.getRowIndex(), c.getColumnIndex())) {

				return mergedRegion;
			}
		}

		return null;
	}

	private static int getColumnIdx(String column) {
		char[] arr = column.toCharArray();
		char temp = 'A';
		int index = 0;
		for (int i = 0; i < arr.length; i++) {
			temp = arr[i];
			int j = 0;
			for (char a = 'A'; a <= 'Z'; a++) {
				if (temp == a) {
					index += j;
					break;
				}
				j++;
			}
			index = j;
		}
		return index;
	}

	private static String[] getSplited(String value, String regex) {
		return value.split(regex);
	}

	private static String createLeaveTable() {
		String padding = "padding:0in 5.4pt 0in 5.4pt;";
		String content = "";
		content += table(
				tr(td(p(b(span(rawHtml("R2 State Rollout Leave Summary for 29<sup>th </sup>October"))
						.withStyle("font-size:10.0pt;color:black;"))).attr("align", "center")
								.withStyle("text-align:center;"))
										.attr("colspan", "4")
										.withStyle("width:764.7pt;border:solid windowtext 1.0pt; background:#FFE699;"
												+ padding + "height:11.5pt")).withStyle("height:11.5pt"),
				tr(td(p(span("Total FTEs").withStyle("font-size:10.0pt;color:black;"))
						.withStyle("text-align:center;font-weight:bold;")).attr("valign", "top")
								.withStyle("border:solid windowtext 1.0pt;background:#BDD7EE;" + padding + ""),
						td(p(span("Planned Leaves").withStyle("font-size:10.0pt;color:black;"))
								.withStyle("text-align:center;font-weight:bold;")).attr("valign", "top")
										.withStyle("border:solid windowtext 1.0pt;background:#BDD7EE;" + padding + ""),
						td(p(span("UnPlanned Leaves").withStyle("font-size:10.0pt;color:black;"))
								.withStyle("text-align:center;font-weight:bold;")).attr("valign", "top")
										.withStyle("border:solid windowtext 1.0pt;background:#BDD7EE;" + padding + ""),
						td(p(span("Work from Home").withStyle("font-size:10.0pt;color:black;"))
								.withStyle("text-align:center;font-weight:bold;")).attr("valign", "top")
										.withStyle("border:solid windowtext 1.0pt;background:#BDD7EE;" + padding + ""))
												.withStyle("height:11.5pt"),
				tr(td(p(span("::84").withStyle("font-size:10.0pt;color:black;"))
						.withStyle("text-align:center;font-weight:bold;")).attr("valign", "top")
								.withStyle("border:solid windowtext 1.0pt;background:#BDD7EE;" + padding + ""),
						td(p(span("::2").withStyle("font-size:10.0pt;color:black;"))
								.withStyle("text-align:center;font-weight:bold;")).attr("valign", "top")
										.withStyle("border:solid windowtext 1.0pt;background:#BDD7EE;" + padding + ""),
						td(p(span("::1").withStyle("font-size:10.0pt;color:black;"))
								.withStyle("text-align:center;font-weight:bold;")).attr("valign", "top")
										.withStyle("border:solid windowtext 1.0pt;background:#BDD7EE;" + padding + ""),
						td(p(span("::1").withStyle("font-size:10.0pt;color:black;"))
								.withStyle("text-align:center;font-weight:bold;")).attr("valign", "top")
										.withStyle("border:solid windowtext 1.0pt;background:#BDD7EE;" + padding + ""))
												.withStyle("height:11.5pt"),
				tr(td(p(span(rawHtml("&nbsp;&nbsp;")).withStyle("font-size:10.0pt;color:black;"))
						.withStyle("text-align:center;")).attr("valign", "top")
								.withStyle("border:solid windowtext 1.0pt;background:white;" + padding + ""),
						td(p(span("1.Suganyha Manoharan").withStyle("font-size:10.0pt;color:black;"))
								.withStyle("text-align:center;")).attr("valign", "top")
										.withStyle("border:solid windowtext 1.0pt;background:white;" + padding + ""),
						td(p(span("1.Prabhu").withStyle("font-size:10.0pt;color:black;"))
								.withStyle("text-align:center;")).attr("valign", "top")
										.withStyle("border:solid windowtext 1.0pt;background:white;" + padding + ""),
						td(p(span("1.Karuna").withStyle("font-size:10.0pt;color:black;"))
								.withStyle("text-align:center;")).attr("valign", "top")
										.withStyle("border:solid windowtext 1.0pt;background:white;" + padding + ""))
												.withStyle("height:11.5pt")).attr("align", "left").withStyle(
														"width:1056.7pt;border-collapse:collapse;margin:6.75pt;")
														.render();
		content += p().render() + p().render() + p().render() + p().render() + p().render() + p().render()
				+ p().render();

		return content;
	}

	private static DomContent getHTMLBody(String string) {

		return body(div(p().attr("class", "MsoNormal"), p().attr("class", "MsoNormal"),
				p(span("Hi All,").withStyle("color:#002060;")).attr("class", "MsoNormal"),
				p().attr("class", "MsoNormal"),
				p(span("Please find daily productivity\r\n" + "report for K2 streams and the overall summary")
						.withStyle("color:#002060;")).attr("class", "MsoNormal"),
				p().attr("class", "MsoNormal"), p().attr("class", "MsoNormal"), rawHtml(string)));
	}

	private static DomContent getHeaderTag() {

		return head(style("@font-face\r\n" + "	{font-family:\"Cambria Math\";} @font-face\r\n"
				+ "	{font-family:Calibri;} p.MsoNormal, li.MsoNormal, div.MsoNormal,  table.MsoNormalTable\r\n"
				+ "	{margin:0in; margin-bottom:.0001pt;	font-size:11.0pt;font-family:\"Calibri\",\"sans-serif\";}"));
	}

}
