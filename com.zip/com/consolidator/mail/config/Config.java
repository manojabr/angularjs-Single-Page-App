package com.consolidator.mail.config;

import java.io.*;
import java.util.*;

import org.json.simple.JSONObject;

import com.consolidator.mail.model.settings;

public class Config {

	static final String ROOT_DIR = System.getProperty("user.dir");
	static final String SETTINGSFile = "settings.json";
	static final String Directory_Separatory = "//";
	static final String MAIL_FILE = "consolidate.eml";
	static final String MAIL_DIR = "Output";

	public static String getMailFile() {
		return getDir() + getDirectorySeparatory() + MAIL_DIR + getDirectorySeparatory() + MAIL_FILE;
	}

	public static String getDir() {
		return ROOT_DIR;
	}

	public static String getSettingfileName() {
		return SETTINGSFile;
	}

	public static String getDirectorySeparatory() {
		return Directory_Separatory;
	}

	private static File settingsFile = null, dir = null;

	public static String getRootDirectoryPath() {
		return getDir();
	}

	public static File getSettingsfile() {
		settingsFile = new File(getDir() + getDirectorySeparatory() + getSettingfileName());
		return settingsFile;
	}

	public static File getMailDir() {
		dir = new File(getDir() + getDirectorySeparatory() + MAIL_DIR + getDirectorySeparatory());
		return dir;
	}

	public static void createDirectory() {
		dir.mkdirs();

	}

	public static void generateSettingsfile() throws Exception {
		settingsFile.createNewFile();
		contentWriter(settingsFile, getjsonContent());
	}

	public static void contentWriter(File file, String content) throws Exception {
		FileWriter writer = new FileWriter(file);
		try {
			writer.write(content);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			writer.flush();
			writer.close();
		}
	}

	public static String getjsonContent() {
		JSONObject obj = new JSONObject();
		List<settings> list = getList();
		for (int i = 0; i < list.size(); i++) {
			obj.put("Name-" + i, list.get(i).getName());
			obj.put("tblind-" + i, list.get(i).getTblindex());
			obj.put("summaryPgName-" + i, list.get(i).getSummaryPgName());
		}
		System.out.println(obj.toString());
		return obj.toJSONString();
	}

	public static ArrayList<settings> getList() {
		ArrayList<settings> list = new ArrayList<settings>();
		list.add(new settings("R2 State Rollout", "A3:G13", ""));
		list.add(new settings("R2-BA", "A2:G24", "Summary"));
		list.add(new settings("R2-Agency Portal", "A2:G9", "Day Summary"));
		list.add(new settings("R2-Comprater", "A2:G9", "Day Summary"));
		list.add(new settings("R2-GW Config", "A2:G10", "Summary"));
		list.add(new settings("R2-GW-Integ", "A2:G9", "Summary"));
		list.add(new settings("R2-Forms", "A2:G11", "Summary"));
		list.add(new settings("R2-PERS", "A2:G13", "Summary"));
		list.add(new settings("R2-QA", "A2:T10", "Summary"));
		return list;
	}

}
