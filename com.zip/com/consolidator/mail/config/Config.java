package com.consolidator.mail.config;

import java.io.*;
import java.util.*;

import org.json.simple.*;

import com.consolidator.mail.model.settings;

public class Config {

	static final String ROOT_DIR = System.getProperty("user.dir");
	static final String SETTINGSFile = "settings.json";
	static final String Directory_Separator = "//";
	static final String MAIL_FILE = "consolidate.eml";
	static final String MAIL_DIR = "Output";
	private static String tblrange;
	private static String[] startIndex;
	private static String[] endIndex;
	private static String regex = "(?<=\\D)(?=\\d)";
	private static String temp = "";

	public static void setTblRange(String tblnge) {
		tblrange = tblnge;
		temp = tblrange.substring(0, tblrange.indexOf(":"));
		startIndex = temp.split(regex);
		temp = tblrange.substring(tblrange.indexOf(":") + 1);
		endIndex = temp.split(regex);
	}

	public String getTblRange() {
		return tblrange;
	}

	public static String getRangeStartNo() {
		return startIndex[1];
	}

	public static String getRangeStartLtr() {
		return startIndex[0];
	}

	public static String getRangeEndNo() {
		return endIndex[1];
	}

	public static String getRangeEndLtr() {
		return endIndex[0];
	}

	public static String getMailFile() {
		return getDir() + getDirectorySeparator() + MAIL_DIR + getDirectorySeparator() + MAIL_FILE;
	}

	public static String getDir() {
		return ROOT_DIR;
	}

	public static String getSettingfileName() {
		return SETTINGSFile;
	}

	public static String getDirectorySeparator() {
		return Directory_Separator;
	}

	private static File settingsFile = null, dir = null;

	public static String getRootDirectoryPath() {
		return getDir();
	}

	public static File getSettingsfile() {
		settingsFile = new File(getDir() + getDirectorySeparator() + getSettingfileName());
		return settingsFile;
	}

	public static File getMailDir() {
		dir = new File(getDir() + getDirectorySeparator() + MAIL_DIR + getDirectorySeparator());
		return dir;
	}

	public static void createDirectory() {
		dir.mkdirs();

	}

	public static void generateSettingsfile() throws Exception {
		settingsFile.createNewFile();
		contentWriter(settingsFile, getjsonContent());
	}
	
	public static int getColumnIdx(String column) {
		char[] arr = column.toCharArray();
		char temp = 'A';
		int index = 0;
		for (int i = 0; i < arr.length; i++) {
			temp = arr[i];
			int j = 0;
			for (char a = 'A'; a <= 'Z'; a++) {
				if (temp == a) {
					index += j;
					break;
				}
				j++;
			}
			index = j;
		}
		return index;
	}


	public static void contentWriter(File file, String content) throws Exception {
		FileWriter writer = new FileWriter(file);
		try {
			writer.write(content);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			writer.flush();
			writer.close();
		}
	}

	@SuppressWarnings("unchecked")
	public static String getjsonContent() {
		JSONObject obj = new JSONObject();
		List<settings> list = getList();
		for (int i = 0; i < list.size(); i++) {
			obj.put("Name-" + i, list.get(i).getName());
			obj.put("tblind-" + i, list.get(i).getTblRange());
			obj.put("summaryPgName-" + i, list.get(i).getSummaryPgName());
		}
		System.out.println(obj.toString());
		return obj.toJSONString();
	}

	public static ArrayList<settings> getList() {
		ArrayList<settings> list = new ArrayList<settings>();
		list.add(new settings("R2 State Rollout", "A3:G13", ""));
		list.add(new settings("R2-BA", "A2:G24", "Summary"));
		list.add(new settings("R2-Agency Portal", "A2:G9", "Day Summary"));
		list.add(new settings("R2-Comprater", "A2:G9", "Day Summary"));
		list.add(new settings("R2-GW Config", "A2:G10", "Summary"));
		list.add(new settings("R2-GW-Integ", "A2:G9", "Summary"));
		list.add(new settings("R2-Forms", "A2:G11", "Summary"));
		list.add(new settings("R2-PERS", "A2:G13", "Summary"));
		list.add(new settings("R2-QA", "A2:T10", "Summary"));
		return list;
	}

}
