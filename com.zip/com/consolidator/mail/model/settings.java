package com.consolidator.mail.model;

public class settings {
	private String Name;
	private String tblrange;
	private String SummaryPgName;

	public String getName() {
		return Name;
	}

	public String getTblRange() {
		return tblrange;
	}

	public String getSummaryPgName() {
		return SummaryPgName;
	}

	public void setName(String name) {
		Name = name;
	}

	public settings(String name, String tblindex, String summaryPgName) {
		Name = name;
		this.tblrange = tblindex;
		SummaryPgName = summaryPgName;
	}

	public settings() {
		super();
	}

	public void setSummaryPgName(String summaryPgName) {
		SummaryPgName = summaryPgName;
	}

}
