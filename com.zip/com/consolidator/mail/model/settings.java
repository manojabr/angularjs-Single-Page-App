package com.consolidator.mail.model;

import java.util.List;

import org.json.simple.*;

public class settings {
	private String Name;
	private String tblindex;
	private String SummaryPgName;
	private List<String> listTitles;

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getTblindex() {
		return tblindex;
	}

	public void setTblindex(String tblindex) {
		this.tblindex = tblindex;
	}

	public String getSummaryPgName() {
		return SummaryPgName;
	}

	public settings(String name, String tblindex, String summaryPgName) {
		Name = name;
		this.tblindex = tblindex;
		SummaryPgName = summaryPgName;
	}

	public void setSummaryPgName(String summaryPgName) {
		SummaryPgName = summaryPgName;
	}

}
